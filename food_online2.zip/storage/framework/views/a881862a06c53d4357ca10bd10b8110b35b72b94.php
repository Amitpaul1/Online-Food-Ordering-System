<nav class="pcoded-navbar">
                        <div class="sidebar_toggle"><a href="#"><i class="icon-close icons"></i></a></div>
                        <div class="pcoded-inner-navbar main-menu">
                            
                            <div class="pcoded-navigatio-lavel" data-i18n="nav.category.navigation">Layout</div>
                            <ul class="pcoded-item pcoded-left-item">
                                <li class="active">
                                    <a href="dashboard.php">
                                        <span class="pcoded-micon"><i class="ti-layout-grid2-alt"></i><b>D</b></span>
                                        <span class="pcoded-mtext" data-i18n="nav.dash.main">Dashboard</span>
                                        <span class="pcoded-mcaret"></span>
                                    </a>
                                </li>
                                <li class="">
                                    <a href="home.php">
                                        <span class="pcoded-micon"><i class="ti-home"></i></span>
                                        <span class="pcoded-mtext"  data-i18n="nav.basic-components.main">Home</span>
                                        <span class="pcoded-mcaret"></span>
                                    </a>
                                     
                                </li>
								 <li class="">
                                    <a href="about.php">
                                        <span class="pcoded-micon"><i class="ti-menu-alt"></i></span>
                                        <span class="pcoded-mtext"  data-i18n="nav.basic-components.main">About</span>
                                        <span class="pcoded-mcaret"></span>
                                    </a>
                                     
                                </li>
								
								<li class="">
                                    <a href="portfoilo.php">
                                        <span class="pcoded-micon"><i class="ti-layout-tab-window"></i></span>
                                        <span class="pcoded-mtext"  data-i18n="nav.basic-components.main">Portfoilo</span>
                                        <span class="pcoded-mcaret"></span>
                                    </a>
                                     
                                </li>
								<li class="">
                                    <a href="testimonial.php">
                                        <span class="pcoded-micon"><i class="ti-layout-slider"></i></span>
                                        <span class="pcoded-mtext"  data-i18n="nav.basic-components.main">Testimonial</span>
                                        <span class="pcoded-mcaret"></span>
                                    </a>
                                     
                                </li>
								<li class="">
                                    <a href="blog.php">
                                        <span class="pcoded-micon"><i class="ti-quote-right"></i></span>
                                        <span class="pcoded-mtext"  data-i18n="nav.basic-components.main">Client</span>
                                        <span class="pcoded-mcaret"></span>
                                    </a>
                                     
                                </li>
									<li class="">
                                    <a href="contact.php">
                                        <span class="pcoded-micon"><i class="ti-hand-point-right"></i></span>
                                        <span class="pcoded-mtext"  data-i18n="nav.basic-components.main">Contact US</span>
                                        <span class="pcoded-mcaret"></span>
                                    </a>
                                     
                                </li>
                            
                    </nav><?php /**PATH C:\xampp\htdocs\food_online\resources\views/Backend/sidebar.blade.php ENDPATH**/ ?>