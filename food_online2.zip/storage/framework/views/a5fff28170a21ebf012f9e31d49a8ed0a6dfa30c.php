<script type="text/javascript" src="<?php echo e('Backend/js/jquery/jquery.min.js'); ?>"></script>
<script type="text/javascript" src="<?php echo e('Backend/js/jquery-ui/jquery-ui.min.js'); ?>"></script>
<script type="text/javascript" src="<?php echo e('Backend/js/popper.js/popper.min.js'); ?>"></script>
<script type="text/javascript" src="<?php echo e('Backend/js/bootstrap/js/bootstrap.min.js'); ?>"></script>
<!-- jquery slimscroll js -->
<script type="text/javascript" src="<?php echo e('Backend/js/jquery-slimscroll/jquery.slimscroll.js'); ?>"></script>
<!-- modernizr js -->
<script type="text/javascript" src="<?php echo e('Backend/js/modernizr/modernizr.js'); ?>"></script>
<!-- am chart -->
<script src="<?php echo e('Backend/pages/widget/amchart/amcharts.min.js'); ?>"></script>
<script src="<?php echo e('Backend/pages/widget/amchart/serial.min.js'); ?>"></script>
<!-- Chart js -->
<script type="text/javascript" src="<?php echo e('Backend/js/chart.js/Chart.js'); ?>"></script>
<!-- Todo js -->
<script type="text/javascript " src="<?php echo e('Backend/pages/todo/todo.js'); ?> "></script>
<!-- Custom js -->
<script type="text/javascript" src="<?php echo e('Backend/pages/dashboard/custom-dashboard.min.js'); ?>"></script>
<script type="text/javascript" src="<?php echo e('Backend/js/script.js'); ?>"></script>
<script type="text/javascript " src="<?php echo e('Backend/js/SmoothScroll.js'); ?>"></script>
<script src="<?php echo e('Backend/js/pcoded.min.js'); ?>"></script>
<script src="<?php echo e('Backend/js/vartical-demo.js'); ?>"></script>
<script src="<?php echo e('Backend/js/jquery.mCustomScrollbar.concat.min.js'); ?>"></script>
</body>

</html><?php /**PATH C:\xampp\htdocs\food_online\resources\views/Backend/footer.blade.php ENDPATH**/ ?>