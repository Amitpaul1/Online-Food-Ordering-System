<?php
use App\Http\Controllers\CartController;
$count=0;
if(Auth::id()){
$count=CartController::cartItem();
}

?>





<!DOCTYPE html>
<html lang="en">


<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Best Restautant Management Software">
    <meta name="keywords" content="restaurant,food,reservation">
    
    <title>ZNM Restaurant – Symphony of dining</title>
    <link rel="shortcut icon" type="image/ico" href="assets/img/icons/2021-05-05/i.html">

    <!--====== Plugins CSS Files =======-->
    <link href="<?php echo e('Frontend/css/bootstrap.min.css'); ?>" rel="stylesheet">
        <link href="<?php echo e('Frontend/css/fontawesome/css/font-awesome.min.css'); ?>" rel="stylesheet">
    <link href="<?php echo e('Frontend/css/themify-icons/themify-icons.css'); ?>" rel="stylesheet">
    <link href=" <?php echo e('Frontend/css/animate.css'); ?>" rel="stylesheet">
    <link href=" <?php echo e('Frontend/css/owl.carousel.min.css'); ?>" rel="stylesheet">
    <link href=" <?php echo e('Frontend/css/metisMenu.min.css'); ?>" rel="stylesheet">
    <link href=" <?php echo e('Frontend/css/bootstrap-datepicker.min.css'); ?>" rel="stylesheet">
    <link href="<?php echo e('Frontend/css/clockpicker.min.css'); ?>" rel="stylesheet">

    <!--====== Custom CSS Files ======-->
    <link href="<?php echo e('Frontend/css/style.css'); ?>" rel="stylesheet">
        <link href="<?php echo e('Frontend/css/responsive.css'); ?>" rel="stylesheet">
    <link href="<?php echo e('Frontend/css/custom/custome.css'); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e('Frontend/css/custom/jquery.rateyo.min.css'); ?>"/>
    <script src="<?php echo e('Frontend/js/jquery-3.3.1.min.js'); ?>"></script>
    <script src="<?php echo e('Frontend/js/product.js.php'); ?>" ></script>
    <script src="<?php echo e('Frontend/js/category.js.php'); ?>" ></script>
 	 <!-- for whatsapp modules -->
     <!-- end whatsapp modules -->
    <!--[if lt IE 9]>
        <script src="//oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
        <script src="//oss.maxcdn.com/respond/1.4.2/respond.min.js"></script> 
    <![endif]-->
</head>

<body>
   
    <!-- Preloader -->
    <div class="preloader"></div>
    
    <!--START HEADER TOP-->
    <header class="header_top_area">
        <div class="header_top">
            <div class="container-fluid">
                <nav class="navbar navbar-expand-lg">
                     <a class="navbar-brand" href="#">ZNM</a>

                   
                    <div class="sidebar-toggle-btn">
                     <a class="nav-link" href="menu.html" id="navbarDropdown3" style="display:inline;color: #fff;">
                                    <i class="ti-shopping-cart"></i><span class="badge badge-notify my-cart-badge" style=";color: #fff; background: #28a745; border-radius: 50px; width: 22px;line-height: 22px; padding:0;">0</span>
                                </a>
                        <button type="button" id="sidebarCollapse" class="btn">
                            <i class="ti-menu"></i>
                        </button>
                        
                    </div>
                    <div class="collapse navbar-collapse" id="navbarTogglerDemo03">
                        <ul class="navbar-nav ml-auto mt-2 mt-lg-0">
                        	                            <li class="nav-item  active">
                                <a class="nav-link " href="<?php echo e(url('/')); ?>" >Home</a>
                                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                                                 </div>
                                
                            </li>
                                                        <li class="nav-item  ">
                                <a class="nav-link " href="<?php echo e(route('about.page')); ?>" >About Us</a>
                                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                                                 </div>
                                
                            </li>
                                                        <li class="nav-item  ">
                                <a class="nav-link " href="<?php echo e(route('menu.page')); ?>" >Our Menu</a>
                                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                                                 </div>
                                
                            </li>
                                                        <li class="nav-item  ">
                                <a class="nav-link " href="<?php echo e(route('reservation.page')); ?>" >Reservation</a>
                                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                                                 </div>
                                
                            </li>
							<?php if(Route::has('login')): ?>
                                   <?php if(auth()->guard()->check()): ?>
                                
                                                        <li class="nav-item dropdown ">
                                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><?php echo e(Auth::user()->name); ?></a>
                                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                                                     <a class="dropdown-item" href="<?php echo e(route('profile.show')); ?>">Profile</a>
																	 <a class="dropdown-item" href="<?php echo e(route('myorder.page')); ?>">Dashboard</a>
                                                                       <form method="POST" action="<?php echo e(route('logout')); ?>">
                                <?php echo csrf_field(); ?>

                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.dropdown-link','data' => ['href' => ''.e(route('logout')).'','onclick' => 'event.preventDefault();
                                                this.closest(\'form\').submit();']]); ?>
<?php $component->withName('jet-dropdown-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['href' => ''.e(route('logout')).'','onclick' => 'event.preventDefault();
                                                this.closest(\'form\').submit();']); ?>
                                    <?php echo e(__('Log Out')); ?>

                                 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                            </form>
                                                                    </div>
                                
                            </li>
						   <?php else: ?>
							<li class="nav-item  ">
                                <a class="nav-link " href="<?php echo e(route('login')); ?>" >Log in</a>
                                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                                                 </div>
                                
                            </li>
							<?php if(Route::has('register')): ?>
							<li class="nav-item  ">
                                <a class="nav-link " href="<?php echo e(route('register')); ?>" >Register</a>
                                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                                                 </div>
                                
                            </li>
							<?php endif; ?>
							<?php endif; ?>
							<?php endif; ?>
							           
                                                       
                                                     
                                                       
                                                       
                            
                            <li class="nav-item">
							<?php if(auth()->guard()->check()): ?>
                                <a class="nav-link" href="cart_show/<?php echo e(Auth::user()->id); ?>" id="navbarDropdown3">
								
                                    <i class="ti-shopping-cart"></i><span class="badge badge-light"><?php echo e($count); ?></span>
                                </a>
								<?php endif; ?>
								<?php if(auth()->guard()->guest()): ?>
                                   Cart[0]
								<?php endif; ?>
                                <!--<div class="dropdown-menu cart_box" aria-labelledby="navbarDropdown3">
                                    <p>Your Cart is Empty</p>
                                </div>-->
                            </li>
							 
                        </ul>
                    </div>
                </nav>
                <!-- /. Navbar -->
                <nav id="sidebar" class="sidebar-nav">
                    <div id="dismiss">
                        <i class="ti-close"></i>
                    </div>
                    <ul class="metismenu list-unstyled" id="mobile-menu">
                    	                        <li>
                            <a href="<?php echo e(url('/')); ?>" >Home </a>
                                                     </li>
                                                <li>
                            <a href="<?php echo e(route('about.page')); ?>" >About Us </a>
                                                     </li>
                                                <li>
                            <a href="<?php echo e(route('menu.page')); ?>" >Our Menu </a>
                                                     </li>
                                                <li>
                            <a href="<?php echo e(route('reservation.page')); ?>" >Reservation </a>
                                                     </li>
                                                 <?php if(Route::has('login')): ?>
                                   <?php if(auth()->guard()->check()): ?>
                                
                                                        <li class="nav-item dropdown ">
                                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><?php echo e(Auth::user()->name); ?></a>
                                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                                                     <a class="dropdown-item" href="<?php echo e(route('profile.show')); ?>">Profile</a>
																	 <a class="dropdown-item" href="mylogin.html">Dashboard</a>
                                                                       <form method="POST" action="<?php echo e(route('logout')); ?>">
                                <?php echo csrf_field(); ?>

                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.dropdown-link','data' => ['href' => ''.e(route('logout')).'','onclick' => 'event.preventDefault();
                                                this.closest(\'form\').submit();']]); ?>
<?php $component->withName('jet-dropdown-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['href' => ''.e(route('logout')).'','onclick' => 'event.preventDefault();
                                                this.closest(\'form\').submit();']); ?>
                                    <?php echo e(__('Log Out')); ?>

                                 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                            </form>
                                                                    </div>
                                
                            </li>
						   <?php else: ?>
							<li class="nav-item  ">
                                <a class="nav-link " href="<?php echo e(route('login')); ?>" >Log in</a>
                                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                                                 </div>
                                
                            </li>
							<?php if(Route::has('register')): ?>
							<li class="nav-item  ">
                                <a class="nav-link " href="<?php echo e(route('register')); ?>" >Register</a>
                                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                                                 </div>
                                
                            </li>
							<?php endif; ?>
							<?php endif; ?>
							<?php endif; ?>
                                                
                                                <li>
                            <a href="menu.html" aria-expanded="false">Cart </a>
                                                     </li>
                                               
                    </ul>
                </nav>
                <div class="overlay"></div>
            </div>
        </div>
         <!--START SLIDER PART--><?php /**PATH C:\xampp\htdocs\food_online\resources\views/header.blade.php ENDPATH**/ ?>