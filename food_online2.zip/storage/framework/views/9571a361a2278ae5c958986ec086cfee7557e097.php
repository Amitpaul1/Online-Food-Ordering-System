<?php echo $__env->make('Backend.page.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

  <body>
  <body>
	
       <!-- Pre-loader start -->
    <div class="theme-loader">
        <div class="loader-track">
            <div class="loader-bar"></div>
        </div>
    </div>
    <!-- Pre-loader end -->
    <div id="pcoded" class="pcoded">
        <div class="pcoded-overlay-box"></div>
        <div class="pcoded-container navbar-wrapper">

           <?php echo $__env->make('Backend.page.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

            <div class="pcoded-main-container">
                <div class="pcoded-wrapper">
                               <?php echo $__env->make('Backend.page.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

                    <div class="pcoded-content">
                        <div class="pcoded-inner-content">
                            <div class="main-body">
                                <div class="page-wrapper">

                                    <div class="page-body">
                                      <div class="row">

                                            <h1>Reservation List</h1>
											<table class="table table-bordered">
  <thead>
    <tr>
      <th scope="col">SL.No</th>
      <th scope="col">Name</th>
      <th scope="col">Email</th>
      <th scope="col">Phone</th>
      <th scope="col">Person</th>
      <th scope="col">Date</th>
      <th scope="col">Time</th>
     
    </tr>
  </thead>
  
 
  <tbody>
  <?php ($i=1); ?>
  <?php $__currentLoopData = $res; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <tr>
  <td><?php echo e($res->firstItem()+$loop->index); ?></td>
  <td><?php echo e($data->Name); ?></td>
  <td><?php echo e($data->Email); ?></td>
  <td><?php echo e($data->Phone); ?></td>
  <td><?php echo e($data->Person); ?></td>
  <td><?php echo e($data->Reservation_Date); ?></td>	
  <td><?php echo e($data->Reservation_Time); ?></td>
  
  
  
  
  
  </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  


  </tbody>
 
</table>
 <?php echo e($res->links()); ?>

 </div>

                                          
 
                                        </div>

                                    <div id="styleSelector">

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

<?php echo $__env->make('Backend.page.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;<?php /**PATH C:\xampp\htdocs\food_online\resources\views/Backend/reservtion.blade.php ENDPATH**/ ?>