<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<style type="text/css">
body {
    background: grey;
    padding:30px;
}


</style>







<!------ Include the above in your HEAD tag ---------->

<div class="container">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body p-0">
                    <div class="row p-5">
                        <div class="col-md-6">
                            <img src="http://via.placeholder.com/400x90?text=logo">
                        </div>

                        <div class="col-md-6 text-right">
                            <p class="font-weight-bold mb-1">ZNM Restaurant</p>
                         <p>House No. 02, Road No.32, Mirpur Road,<br> Dhanmondi, Dhaka-1209,Bangladesh.<br>Phone:01916061927,01397144419<br> Email:zarin@gmail.com</p>
                        </div>
                    </div>
					<div class="row p-5">
                        <div class="col-md-6">
                           <h3>Delivery Address:</h3>
						   
						   <p>Name:<b><?php echo e($orders->Name); ?></b></p>
						   <p style="margin-top:-18px;">Address:<?php echo e($orders->Address); ?></p>
						   <p style="margin-top:-18px;">Phone:<b><?php echo e($orders->Email); ?></b></p>
						   <p style="margin-top:-18px;">Email:<?php echo e($orders->Phone); ?></p>
						   
                        </div>

                        <div class="col-md-6 text-right">
                            <h3>Order Info:</h3>
							<p>Order ID:<b><?php echo e($orders->tracking_no); ?></b></p>
							<p style="margin-top:-18px;">Payment Status:Cash On Delivery</p>
                        </div>
						
                    </div>


                    <div class="row p-5">
                        <div class="col-md-12">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th class="border-0 text-uppercase small font-weight-bold">Sl.NO</th>
                                        <th class="border-0 text-uppercase small font-weight-bold">Name</th>
                                        <th class="border-0 text-uppercase small font-weight-bold">Quantity</th>
                                        <th class="border-0 text-uppercase small font-weight-bold">Unit Cost</th>
                                        <th class="border-0 text-uppercase small font-weight-bold">Total</th>
                                    </tr>
                                </thead>
                                <tbody>
								<?php ($i=1); ?>
								<?php $__currentLoopData = $orders->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
								<td><?php echo e($i++); ?></td>
								<td><?php echo e($value->dishes->Dish_name); ?></td>
								<td><?php echo e($value->quantity); ?></td>
								<td><?php echo e($value->price); ?></td>
								<td><?php echo e($total=(int)$value->quantity * (int)$value->price); ?></td>
								
								
								</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <div class="d-flex flex-row-reverse bg-dark text-white p-4">
                        <div class="py-3 px-5 text-right">
                            <div class="mb-2">Grand Total</div>
                            <div class="h2 font-weight-light"><?php echo e($orders->total_price); ?>TK</div>
                        </div
                    </div>
                </div>
            </div>
        </div>
    </div>
    

</div>








<?php /**PATH C:\xampp\htdocs\food_online\resources\views/Backend/details.blade.php ENDPATH**/ ?>