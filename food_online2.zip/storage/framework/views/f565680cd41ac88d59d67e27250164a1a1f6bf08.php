<?php echo $__env->make('Backend.page.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

  <body>
  <body>
	
       <!-- Pre-loader start -->
    <div class="theme-loader">
        <div class="loader-track">
            <div class="loader-bar"></div>
        </div>
    </div>
    <!-- Pre-loader end -->
    <div id="pcoded" class="pcoded">
        <div class="pcoded-overlay-box"></div>
        <div class="pcoded-container navbar-wrapper">

           <?php echo $__env->make('Backend.page.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

            <div class="pcoded-main-container">
                <div class="pcoded-wrapper">
                               <?php echo $__env->make('Backend.page.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

                    <div class="pcoded-content">
                        <div class="pcoded-inner-content">
                            <div class="main-body">
                                <div class="page-wrapper">

                                    <div class="page-body">
                                      <div class="row">

                                            <h1>Manage Dish</h1>
											<table class="table table-bordered">
  <thead>
    <tr>
      <th scope="col">SL.No</th>
      <th scope="col">Dish Name</th>
      <th scope="col">Catagory Name</th>
      <th scope="col">Dish Image</th>
      <th scope="col">Dish Price</th>
      <th scope="col">Action</th>
	  
     
    </tr>
  </thead>
  <?php if(session('delete')): ?>
		<div class="alert alert-success alert-dismissible fade show" role="alert">
  <strong><?php echo e(session('delete')); ?></strong>
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>
<?php endif; ?>
<?php if(session('update')): ?>
		<div class="alert alert-success alert-dismissible fade show" role="alert">
  <strong><?php echo e(session('update')); ?></strong>
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>
<?php endif; ?>
  <?php ($i=1); ?>
  <?php $__currentLoopData = $dish; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <tbody>
  <tr>
  <td><?php echo e($dish->firstItem()+$loop->index); ?></td>
  <td><?php echo e($value->Dish_name); ?></td>
  <td><?php echo e($value->Cat_Name); ?></td>
  <td><img src="<?php echo e(('Image/').$value->Dish_Img); ?>" style="height:150px; width:150px;"></td>
  <td><?php echo e($value->price); ?></td>
 
	    <td>
	<a class="btn btn-outline-dark" data-toggle="modal" data-target="#edit<?php echo e($value->id); ?>"><i class="ti-arrow-up"></i></a>
	<div class="modal fade" id="edit<?php echo e($value->id); ?>" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Dish Update</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
	  <form action="<?php echo e(route('update_dish')); ?>" method="post">
	  <?php echo csrf_field(); ?>
	  <div class="from-group">
		 <label for="">Dish ID:</label>
		 <input type="hidden" class="form-control" name="dish_id" value="<?php echo e($value->id); ?>" />
		</div>
         <div class="from-group">
		 <label for="">Dish Name:</label>
		 <input type="text" class="form-control" name="dish_name" value="<?php echo e($value->Dish_name); ?>" />
		</div>
		 <div class="from-group">
		 <label for="">Previous Catagory Name:</label>
		 <input type="text" class="form-control" name="cat_name" value="<?php echo e($value->Cat_Name); ?>" />
		</div>
		 <div class="from-group mt-2">
										 <label for="">Catagory Name:</label>
										 <select name="cata_name" class="form-control">
										 <option value="">Select Catagory Name</option>
										 <?php $__currentLoopData = $cata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										 <option value="<?php echo e($data->Cat_id); ?>"><?php echo e($data->Cat_Name); ?></option>
										 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										 </select>
										 
										 </div>
		 <div class="from-group">
		 <label for="">Price:</label>
		 <input type="text" class="form-control" name="dish_price" value="<?php echo e($value->price); ?>" />
		</div>
      </div>
      <div class="modal-footer">
	  <input type="submit" class="btn btn-primary" value="Update" />
	  </form>
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
	<a href="dish/delete/<?php echo e($value->id); ?>" class="btn btn-danger"><i class="ti-trash"></i></a>
  </td>
 
  
  
  </tr>
 
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
<?php echo e($dish->links()); ?>


                                            <!-- statustic and process start -->
                                           <div class="container">
										   
										   
										   
										   </div>

                                        </div>
                                    </div>

                                    <div id="styleSelector">

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

<?php echo $__env->make('Backend.page.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;<?php /**PATH C:\xampp\htdocs\food_online\resources\views/Backend/show_dish.blade.php ENDPATH**/ ?>