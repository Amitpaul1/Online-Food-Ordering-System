<?php
use App\Http\Controllers\CartController;
use App\Models\cart;
$count=0;
if(Auth::id()){
$count=CartController::cartItem();
}

?>







<!DOCTYPE html>
<html lang="en">


<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Best Restautant Management Software">
    <meta name="keywords" content="restaurant,food,reservation">
    
    <title>ZNM Restaurant – Symphony of dining</title>
    <link rel="shortcut icon" type="image/ico" href="assets/img/icons/2021-05-05/i.html">

    <!--====== Plugins CSS Files =======-->
    <link href="<?php echo e(asset('Frontend/css/bootstrap.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('Frontend/css/fontawesome/css/font-awesome.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('Frontend/css/themify-icons/themify-icons.css')); ?>" rel="stylesheet">
    <link href=" <?php echo e(asset('Frontend/css/animate.css')); ?>" rel="stylesheet">
    <link href=" <?php echo e(asset('Frontend/css/owl.carousel.min.css')); ?>" rel="stylesheet">
    <link href=" <?php echo e(asset('Frontend/css/metisMenu.min.css')); ?>" rel="stylesheet">
    <link href=" <?php echo e(asset('Frontend/css/bootstrap-datepicker.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('Frontend/css/clockpicker.min.css')); ?>" rel="stylesheet">

    <!--====== Custom CSS Files ======-->
    <link href="<?php echo e(asset('Frontend/css/style.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('Frontend/css/responsive.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('Frontend/css/custom/custome.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('Frontend/css/custom/jquery.rateyo.min.css')); ?>"/>
    <script src="<?php echo e(asset('Frontend/js/jquery-3.3.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('Frontend/js/product.js.php')); ?>" ></script>
    <script src="<?php echo e(asset('Frontend/js/category.js.php')); ?>" ></script>
 	 <!-- for whatsapp modules -->
     <!-- end whatsapp modules -->
    <!--[if lt IE 9]>
        <script src="//oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
        <script src="//oss.maxcdn.com/respond/1.4.2/respond.min.js"></script> 
    <![endif]-->
	
	
	<style type="text/css">
	
	.a{
		
		
	margin-right:130px;
	}
	
	
	
	
	
	</style>
</head>

<body>
<div class="preloader"></div>
    
    <!--START HEADER TOP-->
    <header class="header_top_area">
        <div class="header_top">
            <div class="container-fluid">
                <nav class="navbar navbar-expand-lg">
                     <a class="navbar-brand" href="#">ZNM</a>

                   
                    <div class="sidebar-toggle-btn">
                     <a class="nav-link" href="menu.html" id="navbarDropdown3" style="display:inline;color: #fff;">
                                    <i class="ti-shopping-cart"></i><span class="badge badge-notify my-cart-badge" style=";color: #fff; background: #28a745; border-radius: 50px; width: 22px;line-height: 22px; padding:0;">0</span>
                                </a>
                        <button type="button" id="sidebarCollapse" class="btn">
                            <i class="ti-menu"></i>
                        </button>
                        
                    </div>
                    <div class="collapse navbar-collapse" id="navbarTogglerDemo03">
                        <ul class="navbar-nav ml-auto mt-2 mt-lg-0">
                        	                            <li class="nav-item  active">
                                <a class="nav-link " href="<?php echo e(url('/')); ?>" >Home</a>
                                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                                                 </div>
                                
                            </li>
                                                        <li class="nav-item  ">
                                <a class="nav-link " href="<?php echo e(route('about.page')); ?>" >About Us</a>
                                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                                                 </div>
                                
                            </li>
                                                        <li class="nav-item  ">
                                <a class="nav-link " href="<?php echo e(route('menu.page')); ?>" >Our Menu</a>
                                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                                                 </div>
                                
                            </li>
                                                        <li class="nav-item  ">
                                <a class="nav-link " href="<?php echo e(route('reservation.page')); ?>" >Reservation</a>
                                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                                                 </div>
                                
                            </li>
							<?php if(Route::has('login')): ?>
                                   <?php if(auth()->guard()->check()): ?>
                                
                                                        <li class="nav-item dropdown ">
                                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><?php echo e(Auth::user()->name); ?></a>
                                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                                                     <a class="dropdown-item" href="<?php echo e(route('profile.show')); ?>">Profile</a>
																	 <a class="dropdown-item" href="mylogin.html">Dashboard</a>
                                                                       <form method="POST" action="<?php echo e(route('logout')); ?>">
                                <?php echo csrf_field(); ?>

                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.dropdown-link','data' => ['href' => ''.e(route('logout')).'','onclick' => 'event.preventDefault();
                                                this.closest(\'form\').submit();']]); ?>
<?php $component->withName('jet-dropdown-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['href' => ''.e(route('logout')).'','onclick' => 'event.preventDefault();
                                                this.closest(\'form\').submit();']); ?>
                                    <?php echo e(__('Log Out')); ?>

                                 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                            </form>
                                                                    </div>
                                
                            </li>
						   <?php else: ?>
							<li class="nav-item  ">
                                <a class="nav-link " href="<?php echo e(route('login')); ?>" >Log in</a>
                                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                                                 </div>
                                
                            </li>
							<?php if(Route::has('register')): ?>
							<li class="nav-item  ">
                                <a class="nav-link " href="<?php echo e(route('register')); ?>" >Register</a>
                                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                                                 </div>
                                
                            </li>
							<?php endif; ?>
							<?php endif; ?>
							<?php endif; ?>
							           
                                                       
                                                     
                                                       
                                                       
                            
                            <li class="nav-item">
                                <a class="nav-link" href="cart_show/<?php echo e(Auth::user()->id); ?>" id="navbarDropdown3">
								<?php if(auth()->guard()->check()): ?>
                                    <i class="ti-shopping-cart"></i><span class="badge badge-light"><?php echo e($count); ?></span>
                                </a>
								<?php endif; ?>
								<?php if(auth()->guard()->guest()): ?>
                         
								<?php endif; ?>
                                <!--<div class="dropdown-menu cart_box" aria-labelledby="navbarDropdown3">
                                    <p>Your Cart is Empty</p>
                                </div>-->
                            </li>
							 
                        </ul>
                    </div>
                </nav>
                <!-- /. Navbar -->
                <nav id="sidebar" class="sidebar-nav">
                    <div id="dismiss">
                        <i class="ti-close"></i>
                    </div>
                    <ul class="metismenu list-unstyled" id="mobile-menu">
                    	                        <li>
                            <a href="<?php echo e(url('/')); ?>" >Home </a>
                                                     </li>
                                                <li>
                            <a href="<?php echo e(route('about.page')); ?>" >About Us </a>
                                                     </li>
                                                <li>
                            <a href="<?php echo e(route('menu.page')); ?>" >Our Menu </a>
                                                     </li>
                                                <li>
                            <a href="<?php echo e(route('reservation.page')); ?>" >Reservation </a>
                                                     </li>
                                                 <?php if(Route::has('login')): ?>
                                   <?php if(auth()->guard()->check()): ?>
                                
                                                        <li class="nav-item dropdown ">
                                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><?php echo e(Auth::user()->name); ?></a>
                                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                                                     <a class="dropdown-item" href="<?php echo e(route('profile.show')); ?>">Profile</a>
																	 <a class="dropdown-item" href="mylogin.html">Dashboard</a>
                                                                       <form method="POST" action="<?php echo e(route('logout')); ?>">
                                <?php echo csrf_field(); ?>

                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.dropdown-link','data' => ['href' => ''.e(route('logout')).'','onclick' => 'event.preventDefault();
                                                this.closest(\'form\').submit();']]); ?>
<?php $component->withName('jet-dropdown-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['href' => ''.e(route('logout')).'','onclick' => 'event.preventDefault();
                                                this.closest(\'form\').submit();']); ?>
                                    <?php echo e(__('Log Out')); ?>

                                 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                            </form>
                                                                    </div>
                                
                            </li>
						   <?php else: ?>
							<li class="nav-item  ">
                                <a class="nav-link " href="<?php echo e(route('login')); ?>" >Log in</a>
                                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                                                 </div>
                                
                            </li>
							<?php if(Route::has('register')): ?>
							<li class="nav-item  ">
                                <a class="nav-link " href="<?php echo e(route('register')); ?>" >Register</a>
                                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                                                 </div>
                                
                            </li>
							<?php endif; ?>
							<?php endif; ?>
							<?php endif; ?>
                                                
                                                <li>
                            <a href="menu.html" aria-expanded="false">Cart </a>
                                                     </li>
                                               
                    </ul>
                </nav>
                <div class="overlay"></div>
            </div>
        </div>
         <!--START SLIDER PART-->
<div class="page_header menu_banner_bg" style="background-image:url(/Frontend/image/menu-banner.jpg);" >
            <div class="container wow fadeIn">
                <div class="row">
                    <div class="col-md-12 col-xs-12">
                        <div class="page_header_content text-center sect_pad">
                            <h1>View Order</h1>
                            <ul class="m-0 nav pt-0 pt-lg-3 justify-content-center">
                                <li><a href="index.html">Home</a></li>
                                <li><i class="fa fa-angle-right"></i></li>
                                <li class="active"><a href="#">View Order</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>

                <div class="container" style="padding:30px;">

                       <div class="card" >
                      
                 <div class="card-body">
                 <table class="table table-striped">
  <thead>
    <tr>
      <th scope="col">Sl.No</th>
      <th scope="col">Dish Name</th>
      <th scope="col">Quantity</th>
      <th scope="col">Price</th>
      
    </tr>
  </thead>
  <tbody>
  <?php ($i=1); ?>
  <?php $__currentLoopData = $orders->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><?php echo e($i++); ?></td>
      <td><?php echo e($data->dishes->Dish_name); ?></td>
      <td><?php echo e($data->quantity); ?></td>
      <td><?php echo e($data->price); ?></td>
    
    </tr>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
                   </div>
                        </div>
					
					
					
					
					
					
					
					</div>



































<section class="map_area">
        <div class="container-fluid">
            <div class="row map_area">
                <div class="map"><p><iframe style="border: 0;" src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d14599.578237069936!2d90.3654215!3d23.8223482!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sen!2sbd!4v1583411739085!5m2!1sen!2sbd" width="300" height="150" frameborder="0" allowfullscreen="allowfullscreen"></iframe></p></div>
                <div class="office_address wow fadeIn" data-wow-delay="0.3s">
                                    <h2 class="mb-4">Our Store</h2>
                    <p>House No. 02, Road No.32, Mirpur Road,<br> Dhanmondi, Dhaka-1209,<br> Bangladesh.<br><br>01916061927,<br>01397144419,<br>0248113086<br><br> zarin@gmail.com</p>                    <button class="simple_btn"><span>Get Directions</span></button>
                </div>
            </div>
        </div>
    </section>
    <!-- End Map Area -->
        <!--Footer Area-->
    <div class="footer-area">
        <div class="container">
            <div class="row footer-inner">
            	                <div class="col-lg-4">
                    <div class="footer-logo-area mb-5 mb-lg-0">
                        
                        <div class="footer-init">
                        <p class="text-justify">ZNM Is A Popular Instrument of Folk & Sufi Music In Kashmir Which Came to India From Iran. However, It’s Origins Are Traced to the shat Tantri Veena ( 100 Stringed Lute ) or the Pinaki Veena Which Is Mentioned In India’s Oldest Religious Work. This Ancient Tool of Music, When Played In The Hands of Devoted Artist Evokes Scintillating Melodies Of Timeless Purity.</p> 
                        </div>
                      <div class="footer-social-bookmark">
                            <ul>
                                                            <li><a href="https://www.facebook.com/"><i class="fa fa-facebook"></i></a></li>
								                                <li><a href="https://www.twitter.com/"><i class="fa fa-twitter"></i></a></li>
								                                <li><a href="https://plus.google.com/"><i class="fa fa-google-plus"></i></a></li>
								                                <li><a href="https://www.pinterest.com/"><i class="fa fa-pinterest"></i></a></li>
								                                <li><a href="https://linkedin.com/"><i class="fa fa-linkedin"></i></a></li>
								                                
                            </ul>
                    </div>
                    </div>
                </div>
                                <div class="col-lg-4">
                    <div class="footer_widget mb-5 mb-lg-0">
                        <h4>Opening Time</h4>
                        <div class="footer_widget_body">
                        <p><strong>Saturday - Friday</strong>   12:00 PM - 10:30 PM</p>
<p> </p>                        </div>
                    </div>
                </div>
                                <div class="col-lg-4">
                    <div class="footer_widget">
                        <h4>Contact Us</h4>
                        <div class="footer_widget_body">
                            <div class="footer-address">
                              <p>House No. 02, Road No.32, Mirpur Road,<br> Dhanmondi, Dhaka-1209,<br> Bangladesh.<br><br>01916061927,<br>01397144419,<br>0248113086<br><br> zarin@gmail.com</p>                            </div>
                        </div>
                    </div>
                </div>
                            </div>
        </div>
        <div class="footer_bottom">
            <div class="container">
                <div class="row">
                    <div class="col-xl-6">
                        <div class="footer-copyright">
                            © 2021 Zarin,Nafija,Molie.
                        </div>
                    </div>
                    <div class="col-xl-6">
                        <div class="footer-menu">
                            <ul>
                                <li><a href="terms.html">Terms of use</a></li>
                                <li><a href="privacy.html">Privacy Policy</a></li>
                                <li><a href="contact.html">Contact</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--End Footer Area-->
    
    

    
    <!-- for whatsapp modules --> 
    <!-- end whatsapp modules -->
    <!--====== SCRIPTS JS ======-->
    <script src="<?php echo e(asset('Frontend/js/jquery-ui.min.js')); ?>" type="text/javascript"></script>
    <link href="<?php echo e(asset('Frontend/css/jquery-ui.min.css')); ?>" rel="stylesheet" type="text/css"/>
    <script src="<?php echo e(asset('Frontend/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('Frontend/js/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('Frontend/js/metisMenu.min.js')); ?>"></script>
    <script src="<?php echo e(asset('Frontend/js/wow.min.js')); ?>"></script>
    <script src="<?php echo e(asset('Frontend/js/bootstrap-datepicker.min.js')); ?>"></script>
    <script src="<?php echo e(asset('Frontend/js/clockpicker.min.js')); ?>"></script>
    <!--<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBDHeh9zEbXo-YCWJcicXH2VRwVwAf_tq0"></script>
    <script src="application/views/themes//assets_web/plugins/gmap/map-active.js"></script>-->
        <!--===== ACTIVE JS=====-->
    <script src="<?php echo e(asset('Frontend/js/custom.js')); ?>"></script>
        <script>
	$(function(){
		$('#navbarTogglerDemo03 ul li a').filter(function(){return this.href==location.href}).parent().addClass('active').siblings().removeClass('active')
		$('#navbarTogglerDemo03 ul li').click(function(){
			$(this).parent().addClass('active').siblings().removeClass('active')	
		})
	});
 
    </script>
    
    
</body>

</html>









<?php /**PATH C:\xampp\htdocs\food_online\resources\views/vieworder.blade.php ENDPATH**/ ?>